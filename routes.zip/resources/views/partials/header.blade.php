<div class="header-area" id="headerArea">
    <div class="container">
    <div class="header-content header-style-five position-relative d-flex align-items-center justify-content-between">
        <div class="logo-wrapper"><a href="#"><img src="img/core-img/logo-sci.png" alt=""></a></div>
        <div class="navbar--toggler" id="affanNavbarToggler" data-bs-toggle="offcanvas" data-bs-target="#affanOffcanvas" aria-controls="affanOffcanvas"><span class="d-block"></span><span class="d-block"></span><span class="d-block"></span></div>
    </div>
    </div>
</div>