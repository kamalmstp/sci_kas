<div wire:loading.delay id="preloader">
    <div class="spinner-grow text-primary" role="status"><span class="visually-hidden">Loading...</span></div>
</div><?php /**PATH C:\xampp\htdocs\sci\laraffan\resources\views/partials/loading.blade.php ENDPATH**/ ?>