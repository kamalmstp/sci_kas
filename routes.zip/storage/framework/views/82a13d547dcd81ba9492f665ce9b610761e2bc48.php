<div class="page-content-wrapper py-3">
    <div class="add-new-contact-wrap">
        <a class="shadow" href="<?php echo e(route('admin.cat.create')); ?>">
            <i class="bi bi-plus-lg"></i>
        </a>
    </div>
    <div class="container">
        <!-- Element Heading -->
        <div class="element-heading mt-3">
            <h6>Category Code</h6>
        </div>
    </div>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion" id="basicaccordion">
                    <!-- Single Accordion -->
                    <div class="accordion-item">
                        <div class="accordion-header" id="heading<?php echo e($row->id); ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($row->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($row->id); ?>">
                                <?php echo e($row->kode); ?>

                            </button>
                        </div>
                        <div class="accordion-collapse collapse" id="collapse<?php echo e($row->id); ?>" aria-labelledby="heading<?php echo e($row->id); ?>" data-bs-parent="#basicaccordion">
                            <div class="accordion-body">
                            <p class="mb-0"><?php echo e($row->keterangan); ?></p>
                                <div class="row">
                                    <a class="btn m-1 btn-sm btn-circle btn-creative btn-warning" href="<?php echo e(route('admin.cat.edit', $row->id)); ?>" data-bs-placement="left"><i class="bi bi-pencil-fill"></i></a>
                                    <button wire:click="destroy(<?php echo e($row->id); ?>)" class="btn m-1 btn-sm btn-circle btn-creative btn-danger" data-bs-placement="left"><i class="bi bi-trash-fill"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\sci\laraffan\resources\views/livewire/administrator/category/index.blade.php ENDPATH**/ ?>