<div class="page-content-wrapper py-3">
    <div class="container">
        <div class="element-heading">
            <h6>Detail Pengeluaran</h6>
        </div>
    </div>
    <div class="container">
        
    </div>
</div><?php /**PATH C:\xampp\htdocs\sci\laraffan\resources\views/livewire/administrator/kas-keluar/show.blade.php ENDPATH**/ ?>