<!DOCTYPE html>
<html lang="en" data-theme="light">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="PT. SUCOFINDO UP Sungai Putting">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#0134d4">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta property="og:url" content="https://kas.upsungaiputting.com" />
    <meta property="og:type" content="Pencatatan Kas Sucofindo UP Sungai Putting" />
    <title>SCI SEI PUTTING</title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">
    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('img/icon.png')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(asset('img/icons/icon-96x96.png')); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('img/icons/icon-152x152.png')); ?>">
    <link rel="apple-touch-icon" sizes="167x167" href="<?php echo e(asset('img/icons/icon-167x167.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('img/icons/icon-180x180.png')); ?>">
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/tiny-slider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/baguetteBox.min.css')); ?>">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/rangeslider.css')); ?>"> -->
    <link rel="stylesheet" href="<?php echo e(asset('css/vanilla-dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/apexcharts.css')); ?>">
    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>" data-turbolinks-track="true" data-turbolinks-eval="false" data-turbolinks-suppress-warning>
    <!-- Web App Manifest -->
    <!-- <link rel="manifest" href="manifest.json"> -->
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

  </head>
  <body>
    <!-- Preloader -->
    <!-- <?php echo $__env->yieldContent('loading'); ?> -->
    <!-- <div id="preloader">
      <div class="spinner-grow text-primary" role="status"><span class="visually-hidden">Loading...</span></div>
    </div> -->
    <!-- Internet Connection Status -->
    <!-- # This code for showing internet connection status -->
    <div class="internet-connection-status" id="internetStatus"></div>
    <!-- Header Area -->
    <?php echo $__env->make('partials.header_simple', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldContent('content'); ?>
    <!-- Footer Nav -->
    <div class="footer-nav-area" id="footerNav">
      <div class="container px-0">
        <?php echo $__env->make('partials.nav-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
    </div>

    <div class="card setting-popup-card shadow-lg" id="settingCard">
      <div class="card-body">
        <div class="container">
          <div class="setting-heading d-flex align-items-center justify-content-between mb-3">
            <p class="mb-0">Settings</p>
            <div class="btn-close" id="settingCardClose"></div>
          </div>
          <div class="single-setting-panel">
            <div class="form-check form-switch mb-2">
              <input class="form-check-input" type="checkbox" id="darkSwitch">
              <label class="form-check-label" for="darkSwitch">Dark mode</label>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- All JavaScript Files -->
    <script src="<?php echo e(mix('js/app.js')); ?>" data-turbolinks-eval="false" data-turbolinks-suppress-warning></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" data-turbolinks-eval="false" data-turbolinks-suppress-warning></script>
    <script src="<?php echo e(asset('js/slideToggle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/internet-status.js')); ?>"></script>
    <script src="<?php echo e(asset('js/tiny-slider.js')); ?>"></script>
    <script src="<?php echo e(asset('js/baguetteBox.min.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset('js/countdown.js')); ?>"></script> -->
    <!-- <script src="<?php echo e(asset('js/rangeslider.min.js')); ?>"></script> -->
    <script src="<?php echo e(asset('js/vanilla-dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/index.js')); ?>"></script>
    <script src="<?php echo e(asset('js/magic-grid.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dark-rtl.js')); ?>"></script>
    <script src="<?php echo e(asset('js/active.js')); ?>" data-turbolinks-track="true" data-turbolinks-eval="false" data-turbolinks-suppress-warning></script>
    <!-- PWA -->
    <!-- <script src="<?php echo e(asset('js/pwa.js')); ?>"></script> -->
    
  </body>
</html><?php /**PATH C:\xampp\htdocs\sci\laraffan\resources\views/layouts/simple.blade.php ENDPATH**/ ?>