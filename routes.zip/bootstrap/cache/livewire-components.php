<?php return array (
  'administrator.category.create' => 'App\\Http\\Livewire\\Administrator\\Category\\Create',
  'administrator.category.edit' => 'App\\Http\\Livewire\\Administrator\\Category\\Edit',
  'administrator.category.index' => 'App\\Http\\Livewire\\Administrator\\Category\\Index',
  'administrator.kas.create' => 'App\\Http\\Livewire\\Administrator\\Kas\\Create',
  'administrator.kas.edit' => 'App\\Http\\Livewire\\Administrator\\Kas\\Edit',
  'administrator.kas.index' => 'App\\Http\\Livewire\\Administrator\\Kas\\Index',
  'administrator.kaskeluar.create' => 'App\\Http\\Livewire\\Administrator\\Kaskeluar\\Create',
  'administrator.kaskeluar.edit' => 'App\\Http\\Livewire\\Administrator\\Kaskeluar\\Edit',
  'administrator.kaskeluar.index' => 'App\\Http\\Livewire\\Administrator\\Kaskeluar\\Index',
  'administrator.kaskeluar.show' => 'App\\Http\\Livewire\\Administrator\\Kaskeluar\\Show',
  'administrator.nota.index' => 'App\\Http\\Livewire\\Administrator\\Nota\\Index',
  'administrator.setting.index' => 'App\\Http\\Livewire\\Administrator\\Setting\\Index',
);